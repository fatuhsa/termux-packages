#!/data/data/io.sanix/files/usr/bin/sh

echo "$@"
