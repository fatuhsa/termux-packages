if [ ! -f /data/data/io.sanix/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/io.sanix/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/io.sanix/files/home/.termux
	cp /data/data/io.sanix/files/usr/share/examples/termux/termux.properties /data/data/io.sanix/files/home/.termux/
fi
