##
## This script is sourced by /data/data/io.sanix/files/usr/bin/login before executing shell.
##
